# Dyno CLone [all in one bot]
A Discord Moderation Bot With Different Features, mostly made for Moderating a Discord Server 

# Features
- ban / unban
- kick 
- lock / unlock
- roles / creating / deleting / giving a member
- clear chat
- mute /unmute
- giveaways
- Reopen
- tickets
- Ping Command
- Many more......

## Self-Hosting 
- Fork the project in your replit
- Run the Replit


Support Server [For any Help]
-
 https://discord.gg/btngw4vaTM